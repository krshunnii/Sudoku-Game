Sudoku
======

This is a Sudoku game programmed using Java and Swing for the GUI. It currently supports 6x6, 9x9, and 12x12 puzzles.

![screenshot](https://raw.githubusercontent.com/mattnenterprise/Sudoku/master/screenshot.png)
